from customtkinter import *
import firebase_admin
from firebase_admin import credentials, storage
from firebase_admin import firestore
from google.cloud.firestore_v1 import SERVER_TIMESTAMP
from tkinter import messagebox, simpledialog
from tkcalendar import Calendar
from PIL import Image
import pickle
import webbrowser
from datetime import datetime, timedelta

cred = credentials.Certificate("serviceAccountKey.json")
# Check if firebase_admin has been initialized
if not firebase_admin._apps:
    firebase_admin.initialize_app(cred, {'storageBucket':'call-a-doctor-20a5d.appspot.com'})

db = firestore.client()

# Global variable to store frameDoctorPg reference
frameDoctorPg = None
frameInitialPg = None
frameAppointmentList = None
lblApStatus = None
lblAppointmentId = None
frameAppointmentIndiv = None

pickleFile = 'userId.pkl'

def checkCurrentUser(pickleFile):
    if os.path.exists(pickleFile) and os.path.getsize(pickleFile) > 0:
        try:
            with open(pickleFile, 'rb') as f:
                pickledData = pickle.load(f)
                if pickledData is not None:
                    currentUser, role = map(str.strip, pickledData.split(','))
                else:
                    currentUser = ""
                    role = ""
        except (EOFError, pickle.UnpicklingError) as e:
            print(f"Error reading '{pickleFile}': {e}")
            currentUser = ""
            role = ""
    else:
        currentUser = ""
        role = ""
        print(f"'The pickle file {pickleFile}' does not exist or is empty.")

    return currentUser, role

def dropSearch_Filter(filter):
    global frameInitialPg
    currentUser, role = checkCurrentUser(pickleFile)
    
    if filter == "Any Time":
        appointmentsRef = db.collection('AppointmentDetails').where('DoctorId', '==', currentUser).where('Status', '==', "Accepted")
    else:
        appointmentsRef = db.collection('AppointmentDetails').where('DoctorId', '==', currentUser).where('Status', '==', "Accepted")
    
    displayAppointments(appointmentsRef)

def btnSearch_Click():
    print("Button Clicked")

def checkTodaysAppointments(lblTodaysApText):
    currentUser, role = checkCurrentUser(pickleFile)
    
    # Get today's date
    today = datetime.date.today()

    # Convert to Firestore Timestamp format for comparison
    startOfDay = datetime.datetime.combine(today, datetime.time.min)
    endOfDay = datetime.datetime.combine(today, datetime.time.max)

    # Query Firestore for appointments
    appointmentsRef = db.collection('AppointmentDetails').where('DoctorId', '==', currentUser)\
                         .where('DateTime', '>=', startOfDay).where('DateTime', '<=', endOfDay)\
                         .where('Status','==','Accepted')
    
    appointments = appointmentsRef.get()

    if appointments:
        # If appointments are found, prepare the text with appointment details
        appointmentsText = "Appointments today:\n"
        for appointment in appointments:
            appointmentData = appointment.to_dict()
            appointmentTime = appointmentData.get('DateTime').strftime('%H:%M')  # Extract and format time
            appointmentId = appointment.id  # Extract AppointmentId
            appointmentsText += f"Time: {appointmentTime}, AppointmentId: {appointmentId}\n"

        lblTodaysApText.configure(text=appointmentsText)
    else:
        # If no appointments are found, update the label with "No appointments today."
        lblTodaysApText.configure(text="No appointments today.")

# Function to display the list of appointments
def displayAppointments(appointmentsRef):
    global frameInitialPg
    global frameAppointmentList
    global lblApStatus
    global btnAppointment_Click

    docs = appointmentsRef.stream()

    # Prepare the data
    appointmentData = []
    for doc in docs:
        appointment = doc.to_dict()
        appointment['AppointmentId'] = doc.id
        appointmentData.append(appointment)

    rowIndex = 3
    
    # Display each appointment data
    for appointment in appointmentData:
        # Prepare appointment information

        status = appointment.get('Status', 'N/A')
        appointmentInfo = (
            f"{appointment['AppointmentId']}\n\n"
            f"Time: {appointment.get('DateTime', 'N/A')}\n"
            f"Type: {appointment.get('AppointmentType', 'N/A')}\n"
            f"Medical Concern: {appointment.get('MedicalConcern', 'N/A')}\n"
        )

        if status == "Completed":
            appointmentInfo += f"Prescription: {appointment.get('Prescription', 'N/A')}\n" 

        # Create a frame for each appointment
        frameAppointmentList = CTkFrame(master=frameInitialPg, bg_color="transparent", fg_color="transparent")
        frameAppointmentList.grid(row=rowIndex, column=0, columnspan=2, sticky="new", padx=47, pady=10)
        frameAppointmentList.grid_columnconfigure(0, weight=1)

        # Add text label
        lblTextAppointment = CTkLabel(master=frameAppointmentList, text=appointmentInfo, height=150, corner_radius=20, 
                                      fg_color="white", bg_color="transparent", text_color="#5D5D5D", font=("Inter", 20), justify="left", anchor="w")
        lblTextAppointment.grid(row=0, column=0, sticky="ew")

        lblApStatus = CTkLabel(master=frameAppointmentList, text=status, fg_color="white", bg_color="transparent", 
                               text_color="#5D5D5D", font=("Inter", 20))
        lblApStatus.grid(row=0, column=0, sticky="e", padx=(0,20))
        
        if status == "Rejected":
            lblApStatus.configure(text_color="red")
        elif status == "Accepted":
            lblApStatus.configure(text_color="green")
        elif status == "Pending":
            lblApStatus.configure(text_color="orange")
        else:
            lblApStatus.configure(text_color="#5D5D5D")

        # Bind click event to the frame
        frameAppointmentList.bind("<Button-1>", lambda e, a=appointment: btnAppointment_Click(a))
        lblTextAppointment.bind("<Button-1>", lambda e, a=appointment: btnAppointment_Click(a))
        lblApStatus.bind("<Button-1>", lambda e, a=appointment: btnAppointment_Click(a))

        rowIndex += 1

def btnBack_Click():
    frameAppointmentIndiv.grid_forget()
    frameInitialPg.grid(row=0, column=0, sticky="news")
        
def btnEditPrescription_Click():
    # Open a simple dialog to get the prescription
    prescriptionDialog = CTkInputDialog(text="Enter the prescription", font=("Inter",12,"bold"),
                                        button_fg_color="#5271FF", entry_border_color="white")

    prescription = prescriptionDialog.get_input()

    # Display the user input
    if prescription:
        print(f"Doctor entered: {prescription}")
        try:
            # Retrieve the text from the label
            appointmentText = lblAppointmentId.cget("text")

            # Remove "Appointment Id:" and strip whitespace
            appointmentId = appointmentText.replace("Appointment Id:", "").strip()
            
            # Update prescription in Firestore
            db.collection('AppointmentDetails').document(appointmentId).update({"Prescription": prescription})
            
            # Show success message
            messagebox.showinfo("Updated", "The prescription has been succesfully updated.")
            
            # Refresh the appointment list and return to initial page
            frameAppointmentIndiv.grid_forget()
            frameInitialPg.grid(row=0, column=0, sticky="news")
            dropSearch_Filter("Any Time")
        
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while updating the prescription: {e}")
    else:
        prescription = None
        print("Doctor did not enter anything or cancelled.")

# Function to open the document in a web browser.
def openDocument(medicalDocs):
    try:
        # Get the download URL for the document from Firebase Storage
        bucket = storage.bucket()
        blob = bucket.blob(medicalDocs)

        # Set expiry time for the URL (e.g., 1 day from now)
        expiryTime = datetime.now() + timedelta(days=1)
        downloadUrl = blob.generate_signed_url(expiryTime)

        # Open the document in the default web browser
        webbrowser.open(downloadUrl)
    
    except Exception as e:
        print(f"Error opening document: {e}")
        
def create_DoctorPg(master):
    global frameDoctorPg
    global frameInitialPg
    global frameAppointmentList
    global lblApStatus
    global lblAppointmentId
    global lblTodaysApText
    global frameAppointmentIndiv
    global btnAppointment_Click
    
    # Frames
    frameDoctorPg = CTkFrame(master=master, fg_color="#B5CAFF", corner_radius=0)
    frameDoctorPg.grid_columnconfigure(0, weight=1)
    frameDoctorPg.grid_rowconfigure(0, weight=1)

    frameInitialPg = CTkScrollableFrame(master=frameDoctorPg, fg_color="#B5CAFF", corner_radius=0, orientation="vertical", 
                                    scrollbar_button_color="white")
    frameInitialPg.grid(row=0, column=0, sticky="news")
    frameInitialPg.grid_columnconfigure(0, weight=1)
    frameInitialPg.grid_rowconfigure(0, weight=1)

    frameCalendar = CTkFrame(master=frameDoctorPg, bg_color="transparent", fg_color="#5271FF", corner_radius=20)
    frameCalendar.grid(row=0, column=1, sticky="news", padx=(22,17), pady=20)

    frameAppointmentIndiv = CTkScrollableFrame(master=frameDoctorPg, fg_color="#B5CAFF", corner_radius=0, orientation="vertical", 
                                    scrollbar_button_color="white")
    frameAppointmentIndiv.grid_columnconfigure(0, weight=1)
    frameAppointmentIndiv.grid_rowconfigure(0, weight=1)

    # Get today's appointments
    lblTodaysAp = CTkLabel(master=frameInitialPg, text="Today's Appointments", font=("Inter",24,"bold"), 
                           text_color="#5271FF")
    lblTodaysAp.grid(row=0, column=0, sticky="new", padx=17, pady=20)

    lblTodaysApText = CTkLabel(master=frameInitialPg, text="No appointments today.", font=("Inter",20), 
                               text_color="#5D5D5D")
    lblTodaysApText.grid(row=0, column=0, sticky="nw", padx=17, pady=(70,20))

    lblCalendar = Calendar(master=frameCalendar, font=("Inter", 35), background="#5271FF", selectbackground="#5271FF", 
                        headersbackground="#B5CAFF", headersforeground="white", normalforeground="#5D5D5D",
                        weekendbackground="white", othermonthforeground="#BDBDBD", othermonthbackground="white", 
                        othermonthweforeground="#BDBDBD", othermonthwebackground="white", borderwidth=3, bordercolor="white", 
                        showweeknumbers=False, firstweekday="sunday", selectmode='day', 
                        disabledbackground="#5271FF", maxdate=datetime.now()+timedelta(days=365), 
                        date_pattern='yyyy-mm-dd')
    lblCalendar.pack(fill="both", expand=True, padx=20, pady=20)

    imglblLineDoctorPg = Image.open("./SE Project/Images/line.png")
    lblLineDoctorPg = CTkLabel(master=frameInitialPg, text="", image=CTkImage(imglblLineDoctorPg, size=(800,1)), bg_color="transparent")
    lblLineDoctorPg.grid(row=1, column=0, columnspan=2, sticky="ew", padx=100, pady=10)

    # Search Bar
    dropSearch = CTkOptionMenu(master=frameInitialPg, values=["Any Time", "Last Week", "Last Month"], fg_color="white", dropdown_fg_color="white",
                            button_color="white", button_hover_color="white", width=206, height=59, anchor="center",
                            corner_radius=20, font=("Inter",20), text_color="#898989", command=dropSearch_Filter)
    dropSearch.grid(row=2, column=0, sticky="nw", padx=47, pady=40)

    tbSearch = CTkEntry(master=frameInitialPg, fg_color="white", width=700, height=59, corner_radius=20, font=("Inter",15), 
                        text_color="black", border_width=0)
    tbSearch.grid(row=2, column=0, sticky="new", padx=(238,47), pady=40)

    lblBehindSearch = CTkLabel(master=frameInitialPg, text="|", font=("Inter",28), text_color="#5271FF", bg_color="white", width=18, 
                                height=59)
    lblBehindSearch.grid(row=2, column=0, sticky="nw", padx=237, pady=40)

    imgBtnSearch = Image.open("./SE Project/Images/search.png")
    BtnSearch = CTkButton(master=frameInitialPg, text="", image=CTkImage(imgBtnSearch, size=(25,25)), 
                        fg_color="white", corner_radius=0, anchor="center", width=25, command=btnSearch_Click)
    BtnSearch.grid(row=2, column=0, sticky="ne", padx=60, pady=55)  

    def btnAppointment_Click(appointment):
        print(f"Appointment clicked: {appointment['AppointmentId']}")

        frameInitialPg.grid_forget()
        frameAppointmentIndiv.grid(row=0, column=0, sticky="news")

        # Fetch data from the referenced collections
        patientId = appointment.get('PatientId')
        clinicId = appointment.get('ClinicId')
        doctorId = appointment.get('DoctorId')

        patientDoc = db.collection('Patients').document(patientId).get()
        clinicDoc = db.collection('Clinics').document(clinicId).get()
        doctorDoc = db.collection('Doctors').document(doctorId).get()

        if patientDoc.exists:
            patientData = patientDoc.to_dict()
        else:
            patientData = {}

        if clinicDoc.exists:
            clinicData = clinicDoc.to_dict()
        else:
            clinicData = {}

        if doctorDoc.exists:
            doctorData = doctorDoc.to_dict()
        else:
            doctorData = {}

        # Populate the clicked on appointment's details frame with the retrieved data
        lblAppointmentId.configure(text=f"Appointment Id: {appointment.get('AppointmentId', 'N/A')}")
        lblAppointmentType.configure(text=f"Type: {appointment.get('AppointmentType', 'N/A')}")
        appointment_datetime = appointment.get('DateTime', 'N/A')

        # Check if appointment_datetime is a Firestore server timestamp
        if appointment_datetime == SERVER_TIMESTAMP:
            appointment_datetime_str = "Pending"  # Placeholder text for server timestamp
        else:
            # Convert Firestore timestamp to datetime object
            appointment_datetime_dt = appointment_datetime.replace(tzinfo=None)  # Remove timezone info if present
            # Format datetime as string without nanoseconds
            appointment_datetime_str = appointment_datetime_dt.strftime('%Y-%m-%d %H:%M:%S')

        # Now concatenate the string with the label text
        lblAppointmentDateTime.configure(text="Date & Time: " + appointment_datetime_str)
        lblMedicalConcern.configure(text="Medical Concern: "+appointment.get('MedicalConcern', 'N/A'))
        medicalDocs = appointment.get('MedicalDocs', 'N/A')
        # Check if medicalDocs is a valid path in Firebase Storage
        if medicalDocs.startswith("MedicalDocs/"):
            # Create a button to view the document
            btnMedicalDocs = CTkButton(master=frameAppointmentIndiv, text="View Related Document(s)", font=("Inter",20,"bold"),
                                    fg_color="#5271FF",command=lambda: openDocument(medicalDocs), anchor="w")
            btnMedicalDocs.grid(row=11, column=0, sticky="w", padx=50)
        else:
            # Display medicalDocs as plain text
            lblMedicalDocs.configure(text=f"Medical Documents: {medicalDocs}")
        lblPrescription.configure(text="Prescription: "+appointment.get('Prescription', 'N/A'))

        status = appointment.get('Status', 'N/A')
        lblStatus.configure(text="Status: "+status)

        lblPatientName.configure(text="Name: "+patientData.get('Name', 'N/A'))
        lblPatientPhone.configure(text=f"Phone No: {patientData.get('PhoneNo', 'N/A')}")
        lblPatientAddress.configure(text="Address: "+patientData.get('Address', 'N/A'))

        lblClinicName.configure(text="Clinic: "+clinicData.get('Name', 'N/A'))

        lblDoctorName.configure(text="Name: "+doctorData.get('Name', 'N/A'))
        lblDoctorSpecialty.configure(text="Specialty: "+doctorData.get('Specialty', 'N/A'))
        lblDoctorPhone.configure(text=f"Phone No: {doctorData.get('PhoneNo', 'N/A')}")

    # Widgets for the individual appointment page
    imgBtnBack = Image.open("./SE Project/Images/back.png")
    btnBack = CTkButton(master=frameAppointmentIndiv, text="", image=CTkImage(imgBtnBack, size=(25,25)), corner_radius=20,
                         fg_color="transparent", width=0, command=btnBack_Click)
    btnBack.grid(row=0, column=0, sticky="nw", pady=20)

    # Appointment information
    lblAppointmentInfo = CTkLabel(master=frameAppointmentIndiv, text="Appointment Information:", font=("Inter",20,"bold"), 
                                  text_color="#5271FF", fg_color="transparent", anchor="w")
    lblAppointmentInfo.grid(row=1, column=0, sticky="we", padx=50, pady=(20,0))

    lblAppointmentId = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblAppointmentId.grid(row=2, column=0, sticky="we", padx=50)
    
    lblAppointmentType = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblAppointmentType.grid(row=3, column=0, sticky="we", padx=50)
    
    lblAppointmentDateTime = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblAppointmentDateTime.grid(row=4, column=0, sticky="we", padx=50)

    lblClinicName = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblClinicName.grid(row=5, column=0, sticky="we", padx=50)

    # Patient Information
    lblPatientInfo = CTkLabel(master=frameAppointmentIndiv, text="Patient Information:", font=("Inter",20, "bold"), 
                              text_color="#5271FF", fg_color="transparent", anchor="w")
    lblPatientInfo.grid(row=6, column=0, sticky="we", padx=50, pady=(20,0))

    lblPatientName = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblPatientName.grid(row=7, column=0, sticky="we", padx=50)

    lblPatientPhone = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblPatientPhone.grid(row=8, column=0, sticky="we", padx=50)

    lblPatientAddress = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblPatientAddress.grid(row=9, column=0, sticky="we", padx=50)

    lblMedicalConcern = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblMedicalConcern.grid(row=10, column=0, sticky="we", padx=50)
    
    lblMedicalDocs = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblMedicalDocs.grid(row=11, column=0, sticky="we", padx=50)

    # Doctor Information
    lblDoctorInfo = CTkLabel(master=frameAppointmentIndiv, text="Doctor Information:", font=("Inter",20,"bold"), 
                             text_color="#5271FF", fg_color="transparent", anchor="w")
    lblDoctorInfo.grid(row=12, column=0, sticky="we", padx=50, pady=(20,0))
    lblDoctorName = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblDoctorName.grid(row=13, column=0, sticky="we", padx=50)

    lblDoctorSpecialty = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblDoctorSpecialty.grid(row=14, column=0, sticky="we", padx=50)

    lblDoctorPhone = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblDoctorPhone.grid(row=15, column=0, sticky="we", padx=50)
    
    lblPrescription = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20), text_color="#5D5D5D",
                              fg_color="transparent", anchor="w")
    lblPrescription.grid(row=16, column=0, sticky="we", padx=50)

    # Status
    lblStatus = CTkLabel(master=frameAppointmentIndiv, text="", font=("Inter",20,"bold"), text_color="#5271FF",
                              fg_color="transparent", anchor="w")
    lblStatus.grid(row=17, column=0, sticky="we", padx=50, pady=30)
    
    # Button to cancel the appointment
    btnEditPrescription = CTkButton(master=frameAppointmentIndiv, text="Edit Prescription", font=("Inter",20,"bold"), 
                                     text_color="white", fg_color="#5271FF", corner_radius=20, command=btnEditPrescription_Click)
    btnEditPrescription.grid(row=18, column=0, padx=50, pady=30) 

    dropSearch_Filter("Any Time")
    
    return frameDoctorPg
